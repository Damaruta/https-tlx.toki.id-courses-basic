import java.util.Scanner;

class c_burung_beo {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        String str = scan.nextLine();
        scan.close();
        System.out.println(str);
    }
}
