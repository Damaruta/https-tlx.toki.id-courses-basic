package main

import "fmt"

func main() {
	var a, b uint8
	fmt.Scanf("%d %d", &a, &b)
	fmt.Println(a + b)
}
