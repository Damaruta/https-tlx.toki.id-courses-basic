A, B = input().split()
print(int(A)+int(B))
