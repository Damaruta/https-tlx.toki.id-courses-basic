A, T = input().split()
print(f'{int(A)*int(T)/2:.2f}')
