#include <stdio.h>
int main()
{
	int A, T;
	scanf("%d %d", &A, &T);
	printf("%.2f", (float)A * T / 2);
	return 0;
}
