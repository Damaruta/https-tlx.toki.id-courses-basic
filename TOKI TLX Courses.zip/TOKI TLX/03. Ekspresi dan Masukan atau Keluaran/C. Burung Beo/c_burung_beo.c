#include <stdio.h>
int main()
{
    char str[101];
    gets(str);
    puts(str);
    return 0;
}
