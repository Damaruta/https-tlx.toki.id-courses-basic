str = input()
print(str)
