#include <bits/stdc++.h>
using namespace std;
int main()
{
    string str;
    getline(cin, str);
    cout << str;
    return 0;
}
