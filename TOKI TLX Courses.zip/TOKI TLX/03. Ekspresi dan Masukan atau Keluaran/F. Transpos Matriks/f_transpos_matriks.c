#include <stdio.h>
int main(){
    int a, b, c, d, e, f, g, h, i;
    scanf("%d %d %d", &a, &b, &c);
    scanf("%d %d %d", &d, &e, &f);
    scanf("%d %d %d", &g, &h, &i);
    printf("%d %d %d\n%d %d %d\n%d %d %d\n", a, d, g, b, e, h, c, f, i);
    return 0;
}
