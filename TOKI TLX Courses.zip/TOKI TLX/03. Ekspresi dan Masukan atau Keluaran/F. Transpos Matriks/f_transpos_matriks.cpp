#include <iostream>
using namespace std;
int main(){
    int a, b, c, d, e, f, g, h, i;
    cin >> a >> b >> c >> d >> e >> f >> g >> h >> i;
    cout << a << " " << d << " " << g << endl;
    cout << b << " " << e << " " << h << endl;
    cout << c << " " << f << " " << i << endl;
    return 0;
}
