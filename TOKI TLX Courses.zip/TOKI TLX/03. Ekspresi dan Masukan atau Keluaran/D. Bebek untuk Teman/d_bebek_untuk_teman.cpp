#include <iostream>
using namespace std;
int main(){
    int N, M;
    cin >> N >> M;
    cout << "masing-masing " << N / M << endl;
    cout << "bersisa " << N % M << endl;
    return 0;
}
