#include <stdio.h>
int main()
{
    printf("Halo, dunia!\n");
    return 0;
}
