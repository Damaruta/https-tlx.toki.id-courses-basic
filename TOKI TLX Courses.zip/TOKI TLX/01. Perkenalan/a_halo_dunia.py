print("Halo, dunia!")
