public class a_halo_dunia {
    public static void main(String args[]){
        System.out.println("Halo, dunia!");
    }
}
