#include <iostream>
using namespace std;
int main()
{
    cout << "Halo, dunia!" << endl;
    return 0;
}
