import java.util.*;

class c_permutasi_zig_zag {
    public static void main(String[] args) {
        try (Scanner scan = new Scanner(System.in)) {
            String str = scan.nextLine();
            int n = Integer.parseInt(str);
            String s = "";
            for (int i = 1; i <= n; i++)
                s += ("" + i);
            permutation(s);
        } catch (NumberFormatException e) {
            e.printStackTrace();
        }
    }

    public static void permutation(String str) {
        permutation("", str);
    }

    private static void permutation(String prefix, String str) {
        int n = str.length();
        if (n == 0) {
            boolean bisa = true;
            for (int i = 1; i < prefix.length() - 1; i++) {
                if (!((prefix.charAt(i - 1) < prefix.charAt(i) && prefix.charAt(i) > prefix.charAt(i + 1)) ||
                        (prefix.charAt(i - 1) > prefix.charAt(i) && prefix.charAt(i) < prefix.charAt(i + 1)))) {
                    bisa = false;
                    break;
                }
            }
            if (bisa)
                System.out.println(prefix);
        } else {
            for (int i = 0; i < n; i++)
                permutation(prefix + str.charAt(i), str.substring(0, i) + str.substring(i + 1, n));
        }
    }
}