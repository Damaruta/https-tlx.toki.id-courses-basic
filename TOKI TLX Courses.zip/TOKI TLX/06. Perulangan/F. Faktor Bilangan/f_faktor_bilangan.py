N = int(input())
for i in range(N, 0, -1):
    if N % i == 0:
        print(i)
