N = int(input())
while N % 2 == 0:
    N = N // 2
print('ya') if N == 1 else print('bukan')
