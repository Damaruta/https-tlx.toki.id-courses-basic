import sys
for str in sys.stdin:
    print(str, end="")
