#include <iostream>
int main(){
  std::string str;
  while (std::cin >> str){
    std::cout << str << std::endl;
  }
  return 0;
}
