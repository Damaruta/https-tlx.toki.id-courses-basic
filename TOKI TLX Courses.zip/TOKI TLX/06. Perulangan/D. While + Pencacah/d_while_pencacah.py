import sys
res = 0
for num in sys.stdin:
    res = res + int(num)
print(res)
