N = int(input())
if (N > 0):
    print("positif")
elif (N < 0):
    print("negatif")
else:
    print("nol")
