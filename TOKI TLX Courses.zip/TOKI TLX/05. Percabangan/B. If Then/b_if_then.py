N = int(input())
if (N > 0):
    print(N)
