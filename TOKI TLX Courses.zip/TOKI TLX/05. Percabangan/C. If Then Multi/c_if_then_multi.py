N = int(input())
if (N > 0 and N % 2 == 0):
    print(N)
